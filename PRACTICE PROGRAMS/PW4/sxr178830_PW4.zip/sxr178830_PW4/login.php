<?php
// Start the session
session_start();

$name=$username="";
// Set session variables
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		# code...
		$name=htmlspecialchars($_POST['name']);
		$username=htmlspecialchars($_POST['username']);
		
		if($name!=""&&$username!=""){
		$_SESSION["name"] = $name;
		$_SESSION["username"] =$username;
		header('Location:welcome.php');
	}
	else{
		header('Location:login.html');
	}
	}
?>